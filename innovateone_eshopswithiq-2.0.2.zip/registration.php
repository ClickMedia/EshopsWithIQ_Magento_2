<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'InnovateOne_EshopsWithIQ',
    __DIR__
);
